from django.contrib import admin
from .models import TpoDetails

# Register your models here.

admin.site.register(TpoDetails)
