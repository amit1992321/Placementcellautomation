from django.apps import AppConfig


class TpoConfig(AppConfig):
    name = 'tpo'
