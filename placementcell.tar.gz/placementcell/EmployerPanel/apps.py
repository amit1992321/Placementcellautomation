from django.apps import AppConfig


class EmployerpanelConfig(AppConfig):
    name = 'EmployerPanel'
