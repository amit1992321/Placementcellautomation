from django.apps import AppConfig


class JobapplicationConfig(AppConfig):
    name = 'JobApplication'
