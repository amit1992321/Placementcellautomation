from django.apps import AppConfig


class StudentpanelConfig(AppConfig):
    name = 'StudentPanel'
